import re
import os

def load_common_passwords(file_name="samples/weak_passwords.txt"):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(script_dir, file_name)

    try:
        with open(file_path, "r") as f:
            return set(line.strip().lower() for line in f if line.strip())
    except FileNotFoundError:
        print("⚠️ Warning: weak_passwords.txt not found. Skipping dictionary check.")
        return set()

def check_password_strength(password, common_passwords):
    feedback = []

    if len(password) < 8:
        feedback.append("❌ Too short. Use at least 8 characters.")
    if not re.search(r"[A-Z]", password):
        feedback.append("❌ Add at least one uppercase letter.")
    if not re.search(r"[a-z]", password):
        feedback.append("❌ Add at least one lowercase letter.")
    if not re.search(r"[0-9]", password):
        feedback.append("❌ Add at least one number.")
    if not re.search(r"[\W_]", password):
        feedback.append("❌ Add at least one special character (!@#...).")
    if password.lower() in common_passwords:
        feedback.append("❌ Avoid using common passwords like '123456', 'password', etc.")

    if not feedback:
        return "✅ Strong password!", []
    else:
        return "⚠️ Weak password.", feedback

if __name__ == "__main__":
    common_passwords = load_common_passwords()
    password = input("🔐 Enter a password to check: ")
    result, tips = check_password_strength(password, common_passwords)

    print("\n" + result)
    for tip in tips:
        print(tip)
